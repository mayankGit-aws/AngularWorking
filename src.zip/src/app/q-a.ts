export class QAndA
{
id:number;
quest:string;
ans:string;

}