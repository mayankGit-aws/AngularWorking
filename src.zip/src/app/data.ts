export const categories= ['Contact','Counter Service','Credit Cards','Current Accounts','General','Global View','Insurance','Loans','Journey Management System'];
export const faqs=[
    {id:1,quest:'How do I get a replacement Secure Key?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:2,quest:'What is internet banking?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:3,quest:'There is fraud on my accounts?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:4,quest:'How can I book an appointment ata branch?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:5,quest:'What is SWIFT code?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:6,quest:'Where can I find my IBAN?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:7,quest:'How can I pay cash into my account?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:8,quest:'How long does it take to apply for a credit card online?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:9,quest:'What should I do if I need to dispute a transaction on my debit card?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:10,quest:'What if I forgot or lock one of my log on details for online banking?',ans:'Sorry, I didnt understand your question. Please could you rephrase it?'},
    {id:11,quest:'What if I have lost my Secure Key?',ans:''}];

    export const journeyMgmtFaqs=[
        {id:1,quest:'How to access Mortgage Offer Documents?',ans:'JMS My Document via RHN'},
        {id:2,quest:'Is application has been completed/submitted to underwiting?',ans:'Yes - Once Underwriting is completed, application status will change to Accept OR No based on application details'},
        {id:3,quest:'How to update D/D details for the mortgage?',ans:'After completing Full Credit Decision, you need to perform Valuation, Direct Debit and Conveyancing. You can complete it in any order.If the page showing valuation as next step , then just launch that function and skip it, it will take you to DD'},
        {id:4,quest:'How to update valuation details for the mortgage?',ans:'After completing Full Credit Decision, you need to perform valuation,Direct Debit and conveyancing. You can compelete it in any order. If valuation details are provided from youe end, then your request is with our valuer and application status would be changed once that done. Thanks for your patience'}

    ]

    

