import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import {routing} from './app-routing';
import {ModalService} from '../modal.service';
import {ModalComponent} from '../modal/modal.component';
import {AppComponent}  from './app.component';
import {FaqsComponent} from '../faqs/faqs.component';
import {AnsComponent} from '../ans/ans.component';

@NgModule({
  declarations: [
    AppComponent,
    ModalComponent,
    FaqsComponent,
    AnsComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    routing
  ],
  providers: [ModalService],
  bootstrap: [AppComponent]
})
export class AppModule { }
